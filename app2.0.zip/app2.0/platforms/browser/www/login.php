<?php
include("conexion.php");
if (!$conn)
{
die("No hay conexion:".mysqli_connect_error());
}
$usuario=$_POST["txtusuario"];
$pass=$_POST["txtpassword"];
$query=mysqli_query($conn,"SELECT * FROM EMPLEADOS where userEmpleado ='".$usuario."' and claveEmpleado = '".$pass."' ");
$nr = mysqli_num_rows($query);

if ($nr==1)
{
header ('location:menu.html');
}
else if ($nr==0) 
{
echo "no ingreso";
}
?>