<?php
include ("conexion.php");

$Clave=$_POST["codigo"];
$Nom=$_POST["nombre"];
$Ape=$_POST["apellido"];
$DNI=$_POST["dni"];
$Direccion=$_POST["direc"];
$email=$_POST["email"];
$Usu=$_POST ["txtusuario"];
$Pass=$_POST["txtpassword"];
$cargo=$_POST["cargo"];

if ($_SERVER['REQUEST_METHOD']=="POST" and isset($_POST['limpiar']))

{
	header("Location: Empleados.html");
}

if ($_SERVER['REQUEST_METHOD']=="POST" and isset($_POST['guardar'])) {
	$sqlgrabar ="INSERT INTO EMPLEADOS (idEmpleado,nomEmpleado,apeEmpleado,dniEmpleado,dirEmpleado,emailEmpleado,userEmpleado,claveEmpleado,cargoEmpleado) values ('$Clave','$Nom','$Ape','$DNI','Direccion','$email','$Usu','$Pass','$cargo')";

if(mysqli_query($conn,$sqlgrabar)){

	header("Location: Empleados.html");
}else{
	echo "Error:" .$sql. "<br>" .mysqli_error($conn);
}
}
if ($_SERVER['REQUEST_METHOD']=="POST" and isset($_POST['editar'])) {
	$sqleditar="UPDATE EMPLEADOS SET nomEmpleado='$Nom',apeEmpleado='$Ape',dniEmpleado=$DNI,dirEmpleado='Direccion',emailEmpleado='$email',userEmpleado='$Usu',claveEmpleado='$Pass',cargoEmpleado='$cargo' WHERE idEmpleado='$Clave'";

if(mysqli_query($conn,$sqleditar)){

	header("Location: Empleados.html");
}else{
	echo "Error:" .$sql. "<br>" .mysqli_error($conn);
}
}

if ($_SERVER['REQUEST_METHOD']=="POST" and isset($_POST['borrar'])) {
	$sqlborrar="DELETE FROM EMPLEADOS WHERE idEmpleado='$Clave'";

if(mysqli_query($conn,$sqlborrar)){

	header("Location: Empleados.html");
}else{
	echo "Error:" .$sql. "<br>" .mysqli_error($conn);
}
}
if ($_SERVER['REQUEST_METHOD']=="POST" and isset($_POST['buscar'])) {
	 $registro= mysqli_query($conn, "SELECT * FROM EMPLEADOS WHERE idEmpleado=$Clave");
echo "<table border ='2'>
<tr>
<td>Id usuario</td>
<td>Nombre del empleado</td>
<td>Apellido del empleado</td>
<td>DNI del empleado</td>
<td>Direccion del empleado</td>
<td>Correo electronico del empleado</td>
<td>Usiario del empleado</td>
<td>Cargo del empleado</td>
</tr>";
while ($reg=mysqli_fetch_array($registro)) {
	echo "<tr><td>".$reg['idEmpleado']."</td>";
    echo "<td>".$reg['nomEmpleado']."</td>";
	echo "<td>".$reg['apeEmpleado']."</td>";
	echo "<td>".$reg['dniEmpleado']."</td>";
	echo "<td>".$reg['dirEmpleado']."</td>";
	echo "<td>".$reg['emailEmpleado']."</td>";
	echo "<td>".$reg['claveEmpleado']."</td>";
	echo "<td>".$reg['cargoEmpleado']."</td></tr>";
	
}
echo "</table>";
}






?>