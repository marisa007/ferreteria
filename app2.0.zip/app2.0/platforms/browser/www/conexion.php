<?php
$dbhost="192.168.0.24";
$dbuser="marisa";
$dbpass="alumnamarisa";
$dbname="sql10406506";

$conn=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
?>