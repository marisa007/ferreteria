<?php
include ("conexion.php");

$Clave=$_POST["codigo"];
$Nom=$_POST["nombre"];
$Stock=$_POST["stock"];
$Des=$_POST["des"];
$PUni=$_POST["PUni"];
$ubi=$_POST["UbicacionP"];
$tipop=$_POST ["tipoproducto"];


if ($_SERVER['REQUEST_METHOD']=="POST" and isset($_POST['limpiar']))

{
	header("Location: Productos.html");
}

if ($_SERVER['REQUEST_METHOD']=="POST" and isset($_POST['guardar'])) {
	$sqlgrabar ="INSERT INTO PRODUCTOS (idProducto,nomProducto,stockProducto,desProducto,precioUnitarioProducto,ubicacionProducto,tipoProducto) values ('$Clave','$Nom','$Stock','$Des','$PUni','$ubi','$tipop')";

if(mysqli_query($conn,$sqlgrabar)){

	header("Location: Productos.html");
}else{
	echo "Error:" .$sql. "<br>" .mysqli_error($conn);
}
}
if ($_SERVER['REQUEST_METHOD']=="POST" and isset($_POST['editar'])) {
	$sqleditar="UPDATE PRODUCTOS SET nomProducto='$Nom',stockProducto='$Stock',desProducto='$Des',precioUnitarioProducto='$PUni',ubicacionProducto='$ubi',tipoProducto='$tipop' WHERE idEmpleado='$Clave'";

if(mysqli_query($conn,$sqleditar)){

	header("Location: Productos.html");
}else{
	echo "Error:" .$sql. "<br>" .mysqli_error($conn);
}
}

if ($_SERVER['REQUEST_METHOD']=="POST" and isset($_POST['borrar'])) {
	$sqlborrar="DELETE FROM PRODUCTOS WHERE idProducto='$Clave'";

if(mysqli_query($conn,$sqlborrar)){

	header("Location: Productos.html");
}else{
	echo "Error:" .$sql. "<br>" .mysqli_error($conn);
}
}

if ($_SERVER['REQUEST_METHOD']=="POST" and isset($_POST['buscar'])) {
	 $registro= mysqli_query($conn, "SELECT * FROM PRODUCTOS WHERE idProducto=$Clave");
echo "<table border ='2'>
<tr>
<td>Id usuario</td>
<td>Nombre del producto</td>
<td>Stock</td>
<td>Descripcion del producto</td>
<td>Precio del producto</td>
<td>Ubicacion del producto</td>
<td>Tipo de producto</td>
</tr>";
while ($reg=mysqli_fetch_array($registro)) {
	echo "<tr><td>".$reg['idProducto']."</td>";
    echo "<td>".$reg['nomProducto']."</td>";
	echo "<td>".$reg['stockProducto']."</td>";
	echo "<td>".$reg['desProducto']."</td>";
	echo "<td>".$reg['precioUnitarioProducto']."</td>";
	echo "<td>".$reg['ubicacionProducto']."</td>";
	echo "<td>".$reg['tipoProducto']."</td></tr>";
	
}
echo "</table>";
}

?>