<?php
include ("conexion.php");

$Clave=$_POST["codigo"];
$Nom=$_POST["nombre"];
$Ape=$_POST["apellido"];
$tel=$_POST ["telefono"];
$Direccion=$_POST["direc"];
$DNI=$_POST["dni"];
$email=$_POST["email"];
$Ruc=$_POST["txtusuario"];

if ($_SERVER['REQUEST_METHOD']=="POST" and isset($_POST['limpiar']))

{
	header("Location: Clientes.html");
}

if ($_SERVER['REQUEST_METHOD']=="POST" and isset($_POST['guardar'])) {
	$sqlgrabar ="INSERT INTO CLIENTES (idCliente,nomCliente,apeCliente,dniCliente,telCliente,rucCliente,dirCliente,emailCliente) values ('$Clave','$Nom','$Ape','$DNI','$tel','$Ruc','$Direccion','$email')";

if(mysqli_query($conn,$sqlgrabar)){

	header("Location: Clientes.html");
}else{
	echo "Error:" .$sql. "<br>" .mysqli_error($conn);
}
}
if ($_SERVER['REQUEST_METHOD']=="POST" and isset($_POST['editar'])) {
	$sqleditar="UPDATE CLIENTES SET nomCliente='$Nom',apeCliente='$Ape',dniCliente=$DNI,telCliente=$tel,rucCliente='$Ruc',dirCliente='Direccion',emailCliente='$email' WHERE idCliente='$Clave'";

if(mysqli_query($conn,$sqleditar)){

	header("Location: Clientes.html");
}else{
	echo "Error:" .$sql. "<br>" .mysqli_error($conn);
}
}

if ($_SERVER['REQUEST_METHOD']=="POST" and isset($_POST['borrar'])) {
	$sqlborrar="DELETE FROM CLIENTES WHERE idCliente='$Clave'";

if(mysqli_query($conn,$sqlborrar)){

	header("Location: Clientes.html");
}else{
	echo "Error:" .$sql. "<br>" .mysqli_error($conn);
}
}
if ($_SERVER['REQUEST_METHOD']=="POST" and isset($_POST['buscar'])) {
	 $registro= mysqli_query($conn, "SELECT * FROM CLIENTES WHERE idCliente=$Clave");
echo "<table border ='2'>
<tr>
<td>Id usuario</td>
<td>Nombre del cliente</td>
<td>Apellido del cliente</td>
<td>DNI del cliente</td>
<td>Telefono del cliente</td>
<td>Ruc del cliente</td>

<td>Direccion del cliente</td>
<td>Correo electronico del cliente</td>
</tr>";
while ($reg=mysqli_fetch_array($registro)) {
	echo "<tr><td>".$reg['idCliente']."</td>";
    echo "<td>".$reg['nomCliente']."</td>";
	echo "<td>".$reg['apeCliente']."</td>";
	echo "<td>".$reg['dniCliente']."</td>";
	echo "<td>".$reg['telCliente']."</td>";
	echo "<td>".$reg['rucCliente']."</td>";
	echo "<td>".$reg['dirCliente']."</td>";
	echo "<td>".$reg['emailCliente']."</td></tr>";
	
}
echo "</table>";
}







?>